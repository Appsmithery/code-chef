// config/env/schema/validate-secrets.ts
import { existsSync as existsSync2, readFileSync as readFileSync2 } from "fs";
import { resolve as resolve2 } from "path";

// config/env/schema/schema-merger.ts
import { existsSync, readFileSync, readdirSync } from "fs";
import { join, resolve } from "path";
function discoverSchemas(options) {
  const {
    coreSchemaPath = "config/env/schema/secrets.core.json",
    overlaysDir = "config/env/schema/overlays",
    submoduleParent = ".."
  } = options;
  let core = null;
  const coreResolved = resolve(coreSchemaPath);
  if (existsSync(coreResolved)) {
    core = JSON.parse(readFileSync(coreResolved, "utf-8"));
  }
  const overlays = /* @__PURE__ */ new Map();
  const overlaysDirResolved = resolve(overlaysDir);
  if (existsSync(overlaysDirResolved)) {
    const files = readdirSync(overlaysDirResolved).filter((f) => f.endsWith(".json"));
    for (const file of files) {
      const filePath = join(overlaysDirResolved, file);
      const schema = JSON.parse(readFileSync(filePath, "utf-8"));
      overlays.set(file, schema);
    }
  }
  const _submoduleSearch = resolve(submoduleParent, "*/config/dev-tools.secrets.schema.json");
  const parentConfigPath = resolve(submoduleParent, "config/dev-tools.secrets.schema.json");
  if (existsSync(parentConfigPath)) {
    const schema = JSON.parse(readFileSync(parentConfigPath, "utf-8"));
    overlays.set("parent-project", schema);
  }
  return { core, overlays };
}
function mergeSchemas(core, overlays) {
  const secretsMap = /* @__PURE__ */ new Map();
  const provenanceMap = /* @__PURE__ */ new Map();
  if (core) {
    for (const secret of core.secrets) {
      secretsMap.set(secret.name, { ...secret, provenance: "core" });
      provenanceMap.set(secret.name, "secrets.core.json");
    }
  }
  for (const [overlayName, overlaySchema] of overlays) {
    for (const secret of overlaySchema.secrets) {
      const existing = secretsMap.get(secret.name);
      if (existing) {
        secretsMap.set(secret.name, {
          ...existing,
          required: existing.required || secret.required,
          sources: Array.from(/* @__PURE__ */ new Set([...existing.sources, ...secret.sources])),
          description: secret.description || existing.description,
          provenance: `${existing.provenance}, ${overlayName}`
        });
      } else {
        secretsMap.set(secret.name, { ...secret, provenance: overlayName });
      }
      provenanceMap.set(secret.name, overlayName);
    }
  }
  return {
    version: core?.version || "1.0.0",
    secrets: Array.from(secretsMap.values()).sort((a, b) => a.name.localeCompare(b.name)),
    provenanceMap
  };
}

// config/env/schema/validate-secrets.ts
function parseArgs() {
  const args = process.argv.slice(2);
  const options = {
    schemas: [],
    envFiles: ["config/env/.env", ".env", "agents/.env.agent.local"],
    format: "human",
    discoverOverlays: false
  };
  for (let i = 0; i < args.length; i++) {
    if (args[i] === "--schema" && args[i + 1]) {
      options.schemas.push(args[++i]);
    } else if (args[i] === "--env-file" && args[i + 1]) {
      options.envFiles.push(args[++i]);
    } else if (args[i] === "--json") {
      options.format = "json";
    } else if (args[i] === "--discover-overlays") {
      options.discoverOverlays = true;
    }
  }
  return options;
}
function loadEnvVars(files) {
  const vars = /* @__PURE__ */ new Map();
  for (const file of files) {
    const filePath = resolve2(file);
    if (!existsSync2(filePath)) continue;
    const content = readFileSync2(filePath, "utf-8");
    for (const line of content.split("\n")) {
      const sanitized = line.replace(/\r$/, "");
      const match = sanitized.match(/^([^#=]+)=(.*)$/);
      if (match) {
        vars.set(match[1].trim(), match[2].trim());
      }
    }
  }
  for (const [key, value] of Object.entries(process.env)) {
    if (value !== void 0) {
      vars.set(key, value);
    }
  }
  return vars;
}
async function validateSecrets() {
  const options = parseArgs();
  const { core, overlays } = discoverSchemas({
    coreSchemaPath: "config/env/schema/secrets.core.json",
    overlaysDir: "config/env/schema/overlays"
  });
  for (const schemaPath of options.schemas || []) {
    if (existsSync2(schemaPath)) {
      const schema = JSON.parse(readFileSync2(schemaPath, "utf-8"));
      overlays.set(schemaPath, schema);
    }
  }
  const merged = mergeSchemas(core, overlays);
  const envVars = loadEnvVars(options.envFiles);
  const missing = [];
  const found = [];
  for (const secret of merged.secrets) {
    const value = envVars.get(secret.name);
    const provenance = merged.provenanceMap.get(secret.name) || "unknown";
    if (!value && secret.required) {
      missing.push({
        name: secret.name,
        provenance,
        description: secret.description
      });
    } else if (value) {
      found.push({ name: secret.name, provenance });
    }
  }
  if (options.format === "json") {
    console.log(
      JSON.stringify(
        {
          valid: missing.length === 0,
          found: found.length,
          missing: missing.length,
          total: merged.secrets.length,
          details: { found, missing },
          provenance: Object.fromEntries(merged.provenanceMap)
        },
        null,
        2
      )
    );
  } else {
    console.log("=== Secrets Validation (Merged Schema) ===\n");
    console.log("Schema Sources:");
    console.log(`  Core: config/env/schema/secrets.core.json`);
    console.log(`  Overlays: ${overlays.size} discovered`);
    for (const name of overlays.keys()) {
      console.log(`    - ${name}`);
    }
    console.log();
    if (found.length > 0) {
      console.log("Found Secrets:");
      for (const { name, provenance } of found) {
        console.log(`  G\uFFFD\uFFFD ${name} (from ${provenance})`);
      }
      console.log();
    }
    if (missing.length > 0) {
      console.log("Missing Required Secrets:");
      for (const { name, provenance, description } of missing) {
        console.log(`  G\uFFFD\uFFFD ${name} (from ${provenance})`);
        console.log(`     ${description}`);
      }
      console.log();
    }
    console.log(`Summary: ${found.length}/${merged.secrets.length} found, ${missing.length} missing`);
  }
  if (missing.length > 0) {
    process.exit(1);
  }
}
validateSecrets().catch((err) => {
  console.error("Validation error:", err);
  process.exit(1);
});
