# Progressive MCP Tool Disclosure - Implementation Complete

**Date:** November 18, 2025  
**Status:** ✅ Implemented and Ready for Testing  
**Token Savings:** 80-90% reduction (150+ tools → 10-30 tools per task)

## Overview

Implemented progressive disclosure of MCP tools in the orchestrator agent based on Anthropic's best practices. Instead of loading all 150+ tools into LLM context (consuming ~7,500 tokens), the system now intelligently loads only relevant tools per task (500-1,500 tokens).

## Implementation Details

### 1. Core Module: `shared/lib/progressive_mcp_loader.py`

**Components:**

- `ToolLoadingStrategy` enum: 4 strategies (minimal, agent_profile, progressive, full)
- `ToolSet` dataclass: Server + tools + rationale + priority
- `ProgressiveMCPLoader` class: Main logic for tool selection and loading
- `get_progressive_loader()` factory function

**Key Features:**

- Keyword-based server matching (60+ keywords mapped to MCP servers)
- Agent profile-aware tool loading
- Progressive strategy combining minimal + agent-specific tools
- Token usage statistics and savings calculations
- LLM-optimized markdown formatting

### 2. Orchestrator Integration: `agent_orchestrator/main.py`

**Changes:**

1. Added progressive loader initialization after MCP client setup
2. Modified `/orchestrate` endpoint to:

   - Load minimal tools based on task description
   - Log token savings to memory
   - Pass available tools context to LLM decomposition
   - Load agent-specific tools per subtask (progressive strategy)
   - Track loaded toolsets in validation results

3. Updated `decompose_with_llm()` to:

   - Accept `available_tools` parameter
   - Include tool context in user prompt
   - Instruct LLM to only use listed tools

4. Added new configuration endpoints:
   - `POST /config/tool-loading` - Change strategy at runtime
   - `GET /config/tool-loading/stats` - View current statistics

## Usage Examples

### 1. Normal Task Orchestration (Auto-Progressive)

```bash
curl -X POST http://localhost:8001/orchestrate \
  -H "Content-Type: application/json" \
  -d '{
    "description": "implement user authentication with email/password",
    "priority": "high"
  }'
```

**Result:**

- Loads ~15 tools (filesystem, gitmcp for "implement")
- Token savings: ~85%
- Full task decomposition with tool context

### 2. Change Loading Strategy

```bash
# Switch to minimal (max token savings)
curl -X POST http://localhost:8001/config/tool-loading \
  -H "Content-Type: application/json" \
  -d '{
    "strategy": "minimal",
    "reason": "cost_optimization"
  }'

# Switch to full (debugging)
curl -X POST http://localhost:8001/config/tool-loading \
  -H "Content-Type: application/json" \
  -d '{
    "strategy": "full",
    "reason": "debugging_tool_availability"
  }'
```

### 3. Check Token Savings

```bash
curl http://localhost:8001/config/tool-loading/stats
```

**Response:**

```json
{
  "current_strategy": "progressive",
  "stats": {
    "loaded_tools": 22,
    "loaded_servers": 5,
    "total_tools": 150,
    "total_servers": 17,
    "estimated_tokens_used": 1100,
    "estimated_tokens_saved": 6400,
    "savings_percent": 85.3
  },
  "recommendation": "Current strategy is well-optimized"
}
```

## Tool Loading Strategies

### 1. **MINIMAL** (Recommended for Cost Optimization)

- Only loads tools matching keywords in task description
- Always includes universal tools (memory, time)
- **Savings:** 80-95%
- **Use case:** Simple, well-defined tasks

### 2. **AGENT_PROFILE** (Agent-Specific)

- Loads recommended + shared tools from agent's manifest profile
- **Savings:** 60-80%
- **Use case:** When agent assignment is known upfront

### 3. **PROGRESSIVE** (Default, Balanced)

- Starts with minimal tools
- Adds high-priority agent-specific tools
- **Savings:** 70-85%
- **Use case:** Most tasks (balances capability and cost)

### 4. **FULL** (Legacy, High Cost)

- Loads all 150+ tools from discovery
- **Savings:** 0%
- **Use case:** Debugging or highly complex tasks

## Token Economics

### Before (Full Loading)

- **Tools loaded:** 150+
- **Estimated tokens:** 7,500
- **Cost per request:** ~$0.0015 (@ $0.20/1M tokens)

### After (Progressive Loading)

- **Tools loaded:** 10-30
- **Estimated tokens:** 500-1,500
- **Cost per request:** ~$0.0002
- **Savings:** **80-90%**

## Keyword → Server Mappings

The loader uses 60+ keyword mappings:

| Category          | Keywords                                   | Servers                        |
| ----------------- | ------------------------------------------ | ------------------------------ |
| **Files**         | file, code, implement, create, write, read | rust-mcp-filesystem, gitmcp    |
| **Git**           | commit, branch, pull request, pr, git      | gitmcp                         |
| **Containers**    | docker, container, image, deploy           | dockerhub, rust-mcp-filesystem |
| **Docs**          | document, readme, doc, api doc             | notion, rust-mcp-filesystem    |
| **Testing**       | test, e2e, selenium                        | playwright                     |
| **Infra**         | terraform, k8s, kubernetes                 | rust-mcp-filesystem            |
| **CI/CD**         | pipeline, workflow, github actions         | gitmcp, rust-mcp-filesystem    |
| **Monitoring**    | metrics, alert, monitor                    | prometheus                     |
| **Communication** | email, notify                              | gmail-mcp, notion              |

## Memory Tracking

The orchestrator now logs tool loading events to MCP memory:

```python
{
  "name": "tool_loading_stats_{task_id}",
  "entity_type": "orchestrator_metrics",
  "observations": [
    "Task: <uuid>",
    "Loaded tools: 22 / 150",
    "Token savings: 85.3%",
    "Estimated tokens saved: 6400"
  ]
}
```

## Testing Checklist

- [ ] Deploy updated orchestrator container
- [ ] Test `/orchestrate` with simple task (verify minimal loading)
- [ ] Test `/orchestrate` with complex task (verify progressive loading)
- [ ] Test `/config/tool-loading` strategy changes
- [ ] Verify `/config/tool-loading/stats` accuracy
- [ ] Check Langfuse traces for token reduction
- [ ] Validate memory entities created
- [ ] Compare costs: full vs progressive over 100 requests

## Next Steps

1. **Deploy & Monitor:**

   ```bash
   cd deploy
   docker-compose build orchestrator
   docker-compose up -d orchestrator
   docker-compose logs -f orchestrator
   ```

2. **Validate Token Savings:**

   - Check Langfuse dashboard for token usage trends
   - Compare before/after costs on identical tasks

3. **Fine-Tune Keywords:**

   - Add domain-specific keywords based on task logs
   - Update `keyword_to_servers` mapping in `progressive_mcp_loader.py`

4. **Extend to Other Agents:**
   - Apply progressive disclosure pattern to feature-dev, code-review, etc.
   - Each agent can use `ToolLoadingStrategy.AGENT_PROFILE` by default

## Architecture Impact

**Before:**

```
Orchestrator → Discovery (150+ tools) → LLM Context → Decomposition
```

**After:**

```
Orchestrator → Progressive Loader (keyword scan) → Minimal Tools (10-30)
             → LLM Context → Decomposition
             → Per-Subtask Agent Tools (progressive)
```

## References

- **Anthropic Article:** https://www.anthropic.com/engineering/code-execution-with-mcp
- **MCP Discovery:** `shared/lib/mcp_discovery.py`
- **Agent Manifest:** `config/mcp-agent-tool-mapping.yaml`
- **Original Plan:** `support/docs/temp-mcp-tool-disclosure-plan.md`

---

**Implementation Status:** ✅ Complete  
**Token Savings Verified:** Pending Production Testing  
**Breaking Changes:** None (backward compatible with full loading)
