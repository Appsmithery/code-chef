## Alternative Notification Strategies (No Enterprise Slack Required)

### Option 1: Linear Comments + Notifications (Recommended ⭐)

**Why This Works Best:**

- ✅ You already get Linear notifications (email, mobile, desktop)
- ✅ Can read/respond to comments on issues
- ✅ Native approval workflow through issue state changes
- ✅ No additional services needed

**Implementation:**

````python
# shared/lib/notifiers/linear_notifier.py

from lib.linear_roadmap import get_roadmap_updater

class LinearNotifier:
    """Post approval requests as Linear issue comments."""

    async def notify_approval_required(self, approval_request: dict):
        """
        Create comment on parent issue with approval request.
        User gets notified via Linear's native notification system.
        """
        updater = get_roadmap_updater()

        # Find or create "Pending Approvals" issue
        pending_issue_id = await self._get_or_create_pending_issue()

        # Post comment with approval details
        comment = f"""
🚨 **Approval Required** (ID: `{approval_request['id']}`)

**Risk Level**: {approval_request['risk_level'].upper()}
**Operation**: {approval_request['operation_type']}
**Environment**: {approval_request['environment']}
**Requested By**: {approval_request['requested_by']}
**Expires**: {approval_request['expires_at']}

**Details**:
```json
{json.dumps(approval_request['metadata'], indent=2)}
````

**To Approve**:

```bash
# Via PowerShell
task workflow:approve {approval_request['id']}

# Via API
curl -X POST http://45.55.173.72:8001/approve/{approval_request['id']} \\
  -H "Content-Type: application/json" \\
  -d '{{"approver_id": "alex@appsmithery.co", "approver_role": "devops_engineer"}}'
```

**To Reject**:

```bash
task workflow:reject {approval_request['id']} "reason here"
```

        """

        await updater.add_comment(pending_issue_id, comment)

        # Update issue state to "Needs Review" to trigger notification
        await updater.update_issue_state(pending_issue_id, "needs_review")

````

**Workflow:**
1. Agent creates approval request → Posts Linear comment → You get notification
2. You read comment in Linear mobile/desktop app
3. Copy-paste approval command into terminal or run from VS Code
4. Agent posts completion comment when approved

---

### Option 2: GitHub Issues + Notifications

**Pros:**
- ✅ Email notifications built-in
- ✅ Mobile app for quick responses
- ✅ Can @mention yourself for guaranteed notification
- ✅ GitHub CLI for quick approvals: `gh issue comment <id> --body "/approve"`

**Implementation:**

```python
# shared/lib/notifiers/github_notifier.py

import httpx

class GitHubNotifier:
    """Post approval requests as GitHub issues in a dedicated repo."""

    def __init__(self):
        self.token = os.getenv("GITHUB_TOKEN")
        self.repo = "vibecoding/dev-tools-approvals"  # Dedicated approvals repo

    async def notify_approval_required(self, approval_request: dict):
        """
        Create GitHub issue for approval request.
        Assign to yourself for notification.
        """
        issue_data = {
            "title": f"🚨 Approval Required: {approval_request['operation_type']}",
            "body": self._format_issue_body(approval_request),
            "labels": [
                f"risk:{approval_request['risk_level']}",
                "approval-pending",
                approval_request['environment']
            ],
            "assignees": ["your-github-username"]  # Auto-assigns to you
        }

        async with httpx.AsyncClient() as client:
            response = await client.post(
                f"https://api.github.com/repos/{self.repo}/issues",
                headers={
                    "Authorization": f"Bearer {self.token}",
                    "Accept": "application/vnd.github.v3+json"
                },
                json=issue_data
            )
            issue = response.json()

            # Store issue URL in approval metadata
            return issue["html_url"]

    def _format_issue_body(self, approval: dict) -> str:
        return f"""
## Approval Request Details

**ID**: `{approval['id']}`
**Risk Level**: `{approval['risk_level'].upper()}`
**Operation**: {approval['operation_type']}
**Environment**: {approval['environment']}
**Requested**: {approval['created_at']}
**Expires**: {approval['expires_at']}

### Metadata
```json
{json.dumps(approval['metadata'], indent=2)}
````

### Approve This Request

**Option 1: Comment on this issue**

```
/approve
```

**Option 2: Run command**

```bash
task workflow:approve {approval['id']}
```

**Option 3: API call**

```bash
curl -X POST http://45.55.173.72:8001/approve/{approval['id']} \\
  -H "Content-Type: application/json" \\
  -d '{{"approver_id": "alex@appsmithery.co", "approver_role": "devops_engineer"}}'
```

### Reject This Request

Comment: `/reject <reason>`

---

_This issue will auto-close when the approval is processed or expires._
"""

````

**GitHub Actions Integration:**

```yaml
# .github/workflows/process-approvals.yml
name: Process Approval Comments

on:
  issue_comment:
    types: [created]

jobs:
  approve:
    if: contains(github.event.comment.body, '/approve')
    runs-on: ubuntu-latest
    steps:
      - name: Extract Approval ID
        id: extract
        run: |
          APPROVAL_ID=$(echo "${{ github.event.issue.body }}" | grep -oP '(?<=ID\`: \`).*?(?=\`)')
          echo "approval_id=$APPROVAL_ID" >> $GITHUB_OUTPUT

      - name: Call Approval API
        run: |
          curl -X POST http://45.55.173.72:8001/approve/${{ steps.extract.outputs.approval_id }} \
            -H "Content-Type: application/json" \
            -d '{"approver_id": "${{ github.actor }}", "approver_role": "devops_engineer"}'

      - name: Close Issue
        run: gh issue close ${{ github.event.issue.number }} --comment "Approved by @${{ github.actor }}"
        env:
          GH_TOKEN: ${{ secrets.GITHUB_TOKEN }}
````

---

### Option 3: VS Code Notifications (Local Development)

**Pros:**

- ✅ Instant desktop notifications while coding
- ✅ No external services needed
- ✅ Can approve directly from VS Code terminal

**Implementation:**

```typescript
// support/frontend/vscode-extension/src/approval-watcher.ts

import * as vscode from "vscode";
import axios from "axios";

export class ApprovalWatcher {
  private statusBarItem: vscode.StatusBarItem;
  private pendingApprovals: number = 0;

  constructor(private orchestratorUrl: string) {
    this.statusBarItem = vscode.window.createStatusBarItem(
      vscode.StatusBarAlignment.Right,
      100
    );
    this.startPolling();
  }

  private async startPolling() {
    setInterval(async () => {
      const approvals = await this.fetchPendingApprovals();

      if (approvals.length > this.pendingApprovals) {
        // New approval request!
        const latest = approvals[0];
        this.showApprovalNotification(latest);
      }

      this.pendingApprovals = approvals.length;
      this.updateStatusBar(approvals);
    }, 10000); // Poll every 10 seconds
  }

  private async showApprovalNotification(approval: any) {
    const action = await vscode.window.showWarningMessage(
      `🚨 Approval Required: ${approval.operation_type} (${approval.risk_level})`,
      "Approve",
      "Reject",
      "View Details"
    );

    if (action === "Approve") {
      await this.approveRequest(approval.id);
    } else if (action === "Reject") {
      const reason = await vscode.window.showInputBox({
        prompt: "Rejection reason",
      });
      if (reason) {
        await this.rejectRequest(approval.id, reason);
      }
    } else if (action === "View Details") {
      vscode.env.openExternal(
        vscode.Uri.parse(`http://localhost:8001/approvals/${approval.id}`)
      );
    }
  }

  private updateStatusBar(approvals: any[]) {
    if (approvals.length === 0) {
      this.statusBarItem.hide();
      return;
    }

    const critical = approvals.filter(
      (a) => a.risk_level === "critical"
    ).length;
    const high = approvals.filter((a) => a.risk_level === "high").length;

    this.statusBarItem.text = `🚨 ${approvals.length} Approval${
      approvals.length > 1 ? "s" : ""
    }`;
    this.statusBarItem.tooltip = `${critical} critical, ${high} high-risk`;
    this.statusBarItem.command = "devtools.showApprovals";
    this.statusBarItem.show();
  }
}
```

**VS Code Extension Commands:**

```json
// support/frontend/vscode-extension/package.json
{
  "contributes": {
    "commands": [
      {
        "command": "devtools.showApprovals",
        "title": "Show Pending Approvals",
        "icon": "$(bell)"
      },
      {
        "command": "devtools.approveSelected",
        "title": "Approve Selected Request"
      }
    ],
    "views": {
      "explorer": [
        {
          "id": "devtoolsApprovals",
          "name": "Pending Approvals"
        }
      ]
    }
  }
}
```

---

### Option 4: Email Notifications (Universal Fallback)

**Pros:**

- ✅ Works everywhere (desktop, mobile)
- ✅ No special accounts needed
- ✅ Can embed approval links

**Implementation:**

```python
# shared/lib/notifiers/email_notifier.py

import smtplib
from email.mime.text import MIMEText
from email.mime.multipart import MIMEMultipart

class EmailNotifier:
    """Send email notifications via SMTP."""

    def __init__(self):
        self.smtp_server = os.getenv("SMTP_SERVER", "smtp.gmail.com")
        self.smtp_port = int(os.getenv("SMTP_PORT", "587"))
        self.from_email = os.getenv("SMTP_FROM", "devtools-bot@appsmithery.co")
        self.password = os.getenv("SMTP_PASSWORD")
        self.to_email = os.getenv("APPROVAL_EMAIL", "alex@appsmithery.co")

    async def notify_approval_required(self, approval_request: dict):
        """Send approval request email with action buttons."""

        # Create email with HTML body
        msg = MIMEMultipart('alternative')
        msg['Subject'] = f"🚨 Approval Required: {approval_request['operation_type']}"
        msg['From'] = self.from_email
        msg['To'] = self.to_email

        # HTML body with action buttons
        html = f"""
        <html>
          <body>
            <h2>Approval Required</h2>
            <p><strong>Risk Level:</strong> <span style="color: red;">{approval_request['risk_level'].upper()}</span></p>
            <p><strong>Operation:</strong> {approval_request['operation_type']}</p>
            <p><strong>Environment:</strong> {approval_request['environment']}</p>
            <p><strong>Expires:</strong> {approval_request['expires_at']}</p>

            <h3>Actions</h3>
            <p>
              <a href="http://45.55.173.72:8001/approve/{approval_request['id']}?approver=alex@appsmithery.co"
                 style="background-color: green; color: white; padding: 10px 20px; text-decoration: none; border-radius: 5px;">
                ✅ Approve
              </a>

              <a href="http://45.55.173.72:8001/approvals/{approval_request['id']}"
                 style="background-color: blue; color: white; padding: 10px 20px; text-decoration: none; border-radius: 5px; margin-left: 10px;">
                📋 View Details
              </a>
            </p>

            <h3>CLI Commands</h3>
            <pre>
# Approve
task workflow:approve {approval_request['id']}

# Reject
task workflow:reject {approval_request['id']} "reason"
            </pre>
          </body>
        </html>
        """

        msg.attach(MIMEText(html, 'html'))

        # Send via SMTP
        with smtplib.SMTP(self.smtp_server, self.smtp_port) as server:
            server.starttls()
            server.login(self.from_email, self.password)
            server.send_message(msg)
```

---

## Recommended Multi-Channel Strategy

### Priority 1: Linear Comments (Primary)

- **Best for**: Async approvals, audit trail
- **Latency**: 5-30 seconds (Linear notification delay)
- **Setup**: Already configured via `linear_roadmap.py`

### Priority 2: VS Code Extension (Development)

- **Best for**: Instant notifications while coding
- **Latency**: <1 second (polling every 10s)
- **Setup**: 2-3 hours to build extension

### Priority 3: Email (Fallback)

- **Best for**: Critical approvals when away from desk
- **Latency**: 1-5 minutes (email delivery + check)
- **Setup**: 30 minutes (configure SMTP)

### Priority 4: GitHub Issues (Optional)

- **Best for**: Team collaboration, public audit trail
- **Latency**: 10-60 seconds
- **Setup**: 1 hour (repo + GitHub Actions)

---

## Implementation Plan for Task 5.2

### Day 1: Linear Comment Notifier

```python
# shared/lib/notifiers/__init__.py
from .linear_notifier import LinearNotifier
from .email_notifier import EmailNotifier

class NotificationManager:
    """Multi-channel notification orchestrator."""

    def __init__(self):
        self.linear = LinearNotifier()
        self.email = EmailNotifier()
        self.enabled_channels = self._get_enabled_channels()

    async def send_approval_notification(self, approval_request: dict):
        """Send notification via all enabled channels."""
        tasks = []

        if "linear" in self.enabled_channels:
            tasks.append(self.linear.notify_approval_required(approval_request))

        if "email" in self.enabled_channels:
            tasks.append(self.email.notify_approval_required(approval_request))

        # Send all notifications concurrently
        results = await asyncio.gather(*tasks, return_exceptions=True)

        # Log failures but don't block
        for channel, result in zip(self.enabled_channels, results):
            if isinstance(result, Exception):
                logger.error(f"Notification failed for {channel}: {result}")
```

### Day 2: VS Code Extension (Optional)

- Create extension scaffold
- Add approval watcher service
- Implement status bar + notifications
- Package as `.vsix` for installation

### Configuration:

```yaml
# config/hitl/notification-config.yaml
channels:
  linear:
    enabled: true
    issue_id: "pending-approvals-board" # Issue to post comments on

  email:
    enabled: true
    smtp_server: smtp.gmail.com
    from: devtools-bot@appsmithery.co
    to: alex@appsmithery.co

  vscode:
    enabled: false # Enable when extension is installed
    poll_interval: 10 # seconds

  github:
    enabled: false
    repo: vibecoding/dev-tools-approvals

routing:
  critical:
    - linear
    - email
  high:
    - linear
  medium:
    - linear
  low:
    - linear
```

---

## Summary

**Best Approach for Your Setup:**

1. **Start with Linear Comments** (already have API access, native notifications)
2. **Add Email for Critical Approvals** (universal, works everywhere)
3. **Build VS Code Extension Later** (nice-to-have for instant feedback)

**No Slack Required!** Linear + Email gives you:

- ✅ Real-time notifications (Linear mobile/desktop)
- ✅ Email fallback for critical items
- ✅ Full audit trail in Linear issues
- ✅ Works with existing tools (no new accounts)
