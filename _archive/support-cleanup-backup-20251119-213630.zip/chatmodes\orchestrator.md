<!-- generated: sync-chatmodes -->

# Orchestrator Agent Chat Mode

Coordinates task routing and agent hand-offs across the development workflow.

This file maps the agent profile to its MCP chat mode configuration.

- **Agent Folder:** `agents/orchestrator`
- **Primary Endpoint:** `/health`
- **Automation:** Managed by `scripts/docs/sync-chatmodes.mjs`
